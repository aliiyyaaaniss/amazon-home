import { FormEvent, ReactElement, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  BrowserRouter,
  Link,
  NavLink,
  Navigate,
  Outlet,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
} from "react-router-dom";

type Category = "home" | "cuisine" | "garden";
type ArticleStatus = "Draft" | "Published";

type Article = {
  id: string;
  title: string;
  category: Category;
  images: string[];
  content: string;
  summary: string;
  rating: number;
  pros: string[];
  cons: string[];
  amazonUrl: string;
  temuUrl: string;
  price: number;
  quality: number;
  value: number;
  durability: number;
  status: ArticleStatus;
  views: number;
  updatedAt: string;
};

type MediaItem = {
  id: string;
  name: string;
  url: string;
  createdAt: string;
};

type ContactMessage = {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  read: boolean;
  createdAt: string;
};

type SiteSettings = {
  siteTitle: string;
  logoText: string;
  socialLinks: {
    instagram: string;
    youtube: string;
    x: string;
  };
};

type AdminCredentials = {
  email: string;
  password: string;
};

const categoryMeta: Record<Category, { title: string; icon: string; note: string }> = {
  home: { title: "Home", icon: "H", note: "Comfort, smart tools, and clean living." },
  cuisine: { title: "Cuisine", icon: "K", note: "Daily cooking tools tested for real kitchens." },
  garden: { title: "Garden", icon: "G", note: "Outdoor picks for healthier and easier gardening." },
};

const defaultSettings: SiteSettings = {
  siteTitle: "VerdiReview",
  logoText: "VR",
  socialLinks: {
    instagram: "https://instagram.com",
    youtube: "https://youtube.com",
    x: "https://x.com",
  },
};

const defaultAdminCredentials: AdminCredentials = {
  email: "admin@verdireview.com",
  password: "Admin123!",
};

const seedArticles: Article[] = [
  {
    id: "air-purifier-360",
    title: "AeroPure 360 Smart Air Purifier",
    category: "home",
    images: [
      "https://images.unsplash.com/photo-1585771724684-38269d6639fd?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=1200&q=80",
    ],
    summary: "Quiet filtration with real-time air quality tracking for medium-size rooms.",
    content:
      "<p>AeroPure 360 impressed us with strong filtration and easy setup. The mobile app displays particulate levels in real time, while auto-mode quickly adjusts fan speed when cooking smoke or dust appears.</p><p>The only tradeoff is that replacement filters are slightly expensive, but overall performance and low noise make it one of the best options in this price range.</p>",
    rating: 4.8,
    price: 159,
    pros: ["Whisper quiet night mode", "Fast PM2.5 response", "Reliable app controls"],
    cons: ["Filter replacements add up", "No carry handle"],
    amazonUrl: "https://www.amazon.com/",
    temuUrl: "https://www.temu.com/",
    quality: 4.9,
    value: 4.5,
    durability: 4.7,
    status: "Published",
    views: 1490,
    updatedAt: "2026-03-20T08:00:00.000Z",
  },
  {
    id: "robot-vac-flex",
    title: "FlexClean Robot Vacuum Pro",
    category: "home",
    images: [
      "https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560185007-5f0bb1866cab?auto=format&fit=crop&w=1200&q=80",
    ],
    summary: "Hands-free sweeping and mopping with practical mapping for apartment layouts.",
    content:
      "<p>FlexClean handles dust and pet hair well and includes mop support for maintenance cleaning. Mapping is solid after two runs and app scheduling is straightforward.</p><p>Obstacle avoidance can miss thin cords, so pre-cleaning floor clutter remains important for best results.</p>",
    rating: 4.4,
    price: 229,
    pros: ["Good pet-hair pickup", "Easy app scheduling", "Mop combo included"],
    cons: ["Average corner reach", "Can miss very thin cables"],
    amazonUrl: "https://www.amazon.com/",
    temuUrl: "https://www.temu.com/",
    quality: 4.4,
    value: 4.6,
    durability: 4.3,
    status: "Published",
    views: 1022,
    updatedAt: "2026-03-18T08:00:00.000Z",
  },
  {
    id: "chef-pan-set",
    title: "CopperCore Nonstick Chef Pan Set",
    category: "cuisine",
    images: [
      "https://images.unsplash.com/photo-1584990347449-a66f8ac1f9c2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1200&q=80",
    ],
    summary: "Responsive cookware with balanced heat control and easy cleanup.",
    content:
      "<p>The CopperCore set heats evenly and gives strong searing performance without hot spots. Handles stay cool during standard stovetop use, and food release is excellent with medium heat.</p><p>For long-term durability, avoid metal utensils and dishwasher cycles.</p>",
    rating: 4.7,
    price: 119,
    pros: ["Even heat distribution", "Comfortable grip", "Fast cleanup"],
    cons: ["Needs gentle utensils", "Moderate oven temperature limit"],
    amazonUrl: "https://www.amazon.com/",
    temuUrl: "https://www.temu.com/",
    quality: 4.8,
    value: 4.6,
    durability: 4.4,
    status: "Published",
    views: 1326,
    updatedAt: "2026-03-22T08:00:00.000Z",
  },
  {
    id: "precision-air-fryer",
    title: "Precision Air Fryer Oven 12L",
    category: "cuisine",
    images: [
      "https://images.unsplash.com/photo-1612198524301-4f3a495d5b2f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1576777647209-e8733d7b851d?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1495521821757-a1efb6729352?auto=format&fit=crop&w=1200&q=80",
    ],
    summary: "Large basket with crispy results and intuitive presets for family meals.",
    content:
      "<p>This fryer consistently produces crisp textures with minimal oil and includes practical presets for fries, chicken, and vegetables. The clear front window helps monitor progress.</p><p>Preheat time is a little longer than premium models, but overall value is excellent.</p>",
    rating: 4.5,
    price: 139,
    pros: ["Large capacity", "Simple touch controls", "Consistent crisp finish"],
    cons: ["Needs counter space", "Longer preheat vs premium models"],
    amazonUrl: "https://www.amazon.com/",
    temuUrl: "https://www.temu.com/",
    quality: 4.5,
    value: 4.8,
    durability: 4.3,
    status: "Draft",
    views: 640,
    updatedAt: "2026-03-24T08:00:00.000Z",
  },
  {
    id: "raised-garden-kit",
    title: "Cedar Raised Garden Bed Kit",
    category: "garden",
    images: [
      "https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1472141521881-95d0e87e2e39?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1463320726281-696a485928c7?auto=format&fit=crop&w=1200&q=80",
    ],
    summary: "Durable cedar frame that assembles quickly and supports deep root growth.",
    content:
      "<p>This raised-bed kit balances easy setup with long-term durability. Cedar planks are thick and weather resistant, and the height supports excellent drainage for herbs and vegetables.</p><p>The included fasteners work, but stainless hardware is a useful upgrade in humid climates.</p>",
    rating: 4.9,
    price: 89,
    pros: ["Easy one-hour assembly", "Premium cedar finish", "Excellent drainage"],
    cons: ["Hardware can be stronger", "Needs yearly sealant in harsh climates"],
    amazonUrl: "https://www.amazon.com/",
    temuUrl: "https://www.temu.com/",
    quality: 4.9,
    value: 4.7,
    durability: 4.8,
    status: "Published",
    views: 1580,
    updatedAt: "2026-03-25T08:00:00.000Z",
  },
  {
    id: "smart-irrigation",
    title: "Smart Drip Irrigation Controller",
    category: "garden",
    images: [
      "https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1622383563227-04401ab4e5ea?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=1200&q=80",
    ],
    summary: "Automates watering with weather-based schedules and app reminders.",
    content:
      "<p>The smart controller reduces daily watering work and helps avoid overwatering through flexible schedules. App setup is quick and notifications are reliable.</p><p>Connectivity can occasionally drop in very large yards without a nearby Wi-Fi extender.</p>",
    rating: 4.3,
    price: 74,
    pros: ["Saves water", "Flexible schedule logic", "Helpful reminders"],
    cons: ["Requires stable Wi-Fi", "Plastic casing feels light"],
    amazonUrl: "https://www.amazon.com/",
    temuUrl: "https://www.temu.com/",
    quality: 4.2,
    value: 4.5,
    durability: 4.1,
    status: "Published",
    views: 940,
    updatedAt: "2026-03-26T08:00:00.000Z",
  },
];

const sectionMotion = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, amount: 0.2 },
  transition: { duration: 0.55, ease: "easeOut" as const },
};

function nowISO() {
  return new Date().toISOString();
}

function formatPrice(price: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(
    price
  );
}

function stars(rating: number) {
  return `${rating.toFixed(1)} / 5`;
}

function stripHtml(value: string) {
  return value.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
}

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
}

function useStoredState<T>(key: string, initialValue: T) {
  const [state, setState] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);

  return [state, setState] as const;
}

function usePageMeta(title: string, description: string) {
  useEffect(() => {
    document.title = title;
    const meta = document.querySelector('meta[name="description"]') ?? document.createElement("meta");
    meta.setAttribute("name", "description");
    meta.setAttribute("content", description);
    if (!meta.parentElement) {
      document.head.appendChild(meta);
    }
  }, [title, description]);
}

async function filesToDataUrls(fileList: FileList) {
  const files = Array.from(fileList);
  const data = await Promise.all(
    files.map(
      (file) =>
        new Promise<{ name: string; url: string }>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve({ name: file.name, url: String(reader.result) });
          reader.onerror = () => reject(new Error(`Failed to read file: ${file.name}`));
          reader.readAsDataURL(file);
        })
    )
  );
  return data;
}

function Header({
  darkMode,
  onToggle,
  settings,
}: {
  darkMode: boolean;
  onToggle: () => void;
  settings: SiteSettings;
}) {
  const navItems = [
    { to: "/", label: "Home" },
    { to: "/category/home", label: "Home" },
    { to: "/category/cuisine", label: "Cuisine" },
    { to: "/category/garden", label: "Garden" },
    { to: "/about", label: "About" },
    { to: "/contact", label: "Contact" },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-green-900/10 bg-white/85 backdrop-blur-md dark:border-green-50/10 dark:bg-[#091510]/90">
      <nav className="mx-auto flex w-full max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-3">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-green-900 text-xs font-bold text-white">
            {settings.logoText.slice(0, 2).toUpperCase()}
          </span>
          <span className="text-lg font-bold tracking-tight text-green-950 dark:text-green-100">{settings.siteTitle}</span>
        </Link>
        <div className="hidden items-center gap-5 text-sm md:flex">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                isActive
                  ? "text-orange-600 dark:text-orange-300"
                  : "text-green-900 transition hover:text-orange-600 dark:text-green-50 dark:hover:text-orange-300"
              }
            >
              {item.label}
            </NavLink>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <Link
            to="/admin"
            className="rounded-md border border-green-900/20 px-3 py-1 text-sm text-green-900 transition hover:border-orange-500 hover:text-orange-600 dark:border-green-50/20 dark:text-green-50"
          >
            Admin
          </Link>
          <button
            onClick={onToggle}
            className="rounded-md border border-green-900/20 px-3 py-1 text-sm text-green-900 transition hover:border-orange-500 hover:text-orange-600 dark:border-green-50/20 dark:text-green-50"
          >
            {darkMode ? "Light" : "Dark"}
          </button>
        </div>
      </nav>
    </header>
  );
}

function Breadcrumbs() {
  const location = useLocation();
  const parts = location.pathname.split("/").filter(Boolean);

  if (parts.length === 0 || parts[0] === "admin") {
    return null;
  }

  return (
    <div className="mx-auto w-full max-w-7xl px-4 pb-2 pt-4 text-xs text-green-800/85 dark:text-green-200/80 sm:px-6 lg:px-8">
      <Link to="/" className="transition hover:text-orange-500">
        Home
      </Link>
      {parts.map((part, index) => (
        <span key={`${part}-${index}`}>
          <span className="px-2">/</span>
          {part[0].toUpperCase() + part.slice(1)}
        </span>
      ))}
    </div>
  );
}

function ProductRow({ article }: { article: Article }) {
  return (
    <motion.article
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
      className="grid gap-4 border-b border-green-900/10 py-6 sm:grid-cols-[220px_1fr] dark:border-green-50/10"
    >
      <img src={article.images[0]} alt={article.title} className="h-44 w-full object-cover" loading="lazy" decoding="async" />
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-xl font-semibold text-green-950 dark:text-green-50">{article.title}</h3>
          <span className="text-lg font-bold text-orange-600 dark:text-orange-300">{formatPrice(article.price)}</span>
        </div>
        <p className="text-sm font-medium text-green-900/90 dark:text-green-100/90">{stars(article.rating)}</p>
        <p className="text-sm text-green-900/80 dark:text-green-100/80">{article.summary}</p>
        <div className="flex flex-wrap gap-2 text-xs">
          {article.pros.slice(0, 2).map((pro) => (
            <span key={pro} className="bg-green-100 px-3 py-1 text-green-800 dark:bg-green-900/50 dark:text-green-100">
              + {pro}
            </span>
          ))}
          {article.cons.slice(0, 2).map((con) => (
            <span key={con} className="bg-orange-100 px-3 py-1 text-orange-800 dark:bg-orange-900/40 dark:text-orange-100">
              - {con}
            </span>
          ))}
        </div>
        <div className="flex flex-wrap gap-3 text-sm font-medium">
          <a href={article.amazonUrl} target="_blank" rel="noreferrer" className="bg-green-900 px-4 py-2 text-white transition hover:bg-green-800">
            Buy on Amazon
          </a>
          <a
            href={article.temuUrl}
            target="_blank"
            rel="noreferrer"
            className="border border-orange-500 px-4 py-2 text-orange-700 transition hover:bg-orange-500 hover:text-white dark:border-orange-300 dark:text-orange-200 dark:hover:bg-orange-300 dark:hover:text-green-950"
          >
            Buy on Temu
          </a>
          <Link
            to={`/product/${article.id}`}
            className="border border-green-900/25 px-4 py-2 text-green-900 transition hover:bg-green-900 hover:text-white dark:border-green-50/30 dark:text-green-50 dark:hover:bg-green-100 dark:hover:text-green-950"
          >
            Full Review
          </Link>
        </div>
      </div>
    </motion.article>
  );
}

function HomePage({
  siteTitle,
  search,
  setSearch,
  publishedArticles,
}: {
  siteTitle: string;
  search: string;
  setSearch: (value: string) => void;
  publishedArticles: Article[];
}) {
  usePageMeta(
    `${siteTitle} | Trusted Amazon & Temu Reviews for Home, Cuisine, and Garden`,
    "Discover honest Amazon and Temu product reviews for Home, Kitchen, and Garden with ratings, comparisons, and best weekly picks."
  );

  const featured = useMemo(
    () => publishedArticles.slice().sort((a, b) => b.rating - a.rating).slice(0, 3),
    [publishedArticles]
  );
  const bestPicks = useMemo(() => publishedArticles.filter((item) => item.rating >= 4.7).slice(0, 3), [publishedArticles]);
  const visibleFeatured = useMemo(() => {
    if (!search.trim()) {
      return featured;
    }
    const query = search.toLowerCase();
    return publishedArticles
      .filter((item) => `${item.title} ${item.summary}`.toLowerCase().includes(query))
      .slice(0, 4);
  }, [search, featured, publishedArticles]);

  const [compareA, setCompareA] = useState(publishedArticles[0]?.id ?? "");
  const [compareB, setCompareB] = useState(publishedArticles[1]?.id ?? "");

  useEffect(() => {
    if (!publishedArticles.some((item) => item.id === compareA)) {
      setCompareA(publishedArticles[0]?.id ?? "");
    }
    if (!publishedArticles.some((item) => item.id === compareB)) {
      setCompareB(publishedArticles[1]?.id ?? publishedArticles[0]?.id ?? "");
    }
  }, [publishedArticles, compareA, compareB]);

  const a = publishedArticles.find((item) => item.id === compareA);
  const b = publishedArticles.find((item) => item.id === compareB);

  return (
    <>
      <section className="relative overflow-hidden bg-[#0f2d21] text-white">
        <img
          src="https://images.unsplash.com/photo-1493666438817-866a91353ca9?auto=format&fit=crop&w=2000&q=80"
          alt="Warm interior kitchen and home scene"
          className="absolute inset-0 h-full w-full object-cover opacity-35"
        />
        <div className="relative mx-auto flex min-h-[74vh] w-full max-w-7xl flex-col justify-center px-4 py-20 sm:px-6 lg:px-8">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-sm uppercase tracking-[0.26em] text-orange-200"
          >
            {siteTitle}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.1 }}
            className="mt-4 max-w-3xl text-4xl font-bold leading-tight sm:text-5xl"
          >
            Smart shopping starts with trusted reviews for your home, kitchen, and garden.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-5 max-w-2xl text-base text-green-100/95 sm:text-lg"
          >
            Explore hand-picked Amazon and Temu reviews with transparent pros, cons, and price checks.
          </motion.p>
          <motion.form
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            onSubmit={(event) => event.preventDefault()}
            className="mt-8 flex w-full max-w-xl flex-col gap-3 sm:flex-row"
          >
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search products, brands, or use-cases"
              className="h-12 flex-1 border border-white/30 bg-white/95 px-4 text-sm text-green-950 outline-none ring-orange-300 focus:ring-2"
            />
            <Link to="/category/home" className="inline-flex h-12 items-center justify-center bg-orange-500 px-6 text-sm font-semibold text-white transition hover:bg-orange-400">
              Explore Reviews
            </Link>
          </motion.form>
        </div>
      </section>

      <main className="mx-auto w-full max-w-7xl space-y-20 px-4 py-16 sm:px-6 lg:px-8">
        <motion.section {...sectionMotion}>
          <div className="flex items-end justify-between gap-4">
            <h2 className="text-3xl font-bold text-green-950 dark:text-green-50">Featured and Trending Reviews</h2>
            <Link to="/category/home" className="text-sm font-semibold text-orange-600 dark:text-orange-300">
              View all categories
            </Link>
          </div>
          <div className="mt-7 divide-y divide-green-900/10 dark:divide-green-50/10">
            {visibleFeatured.map((item) => (
              <ProductRow key={item.id} article={item} />
            ))}
          </div>
        </motion.section>

        <motion.section {...sectionMotion}>
          <h2 className="text-3xl font-bold text-green-950 dark:text-green-50">Review Categories</h2>
          <p className="mt-2 max-w-2xl text-green-900/75 dark:text-green-100/80">
            One clear goal in each section: help you find the best match quickly.
          </p>
          <div className="mt-8 grid gap-5 sm:grid-cols-3">
            {(Object.keys(categoryMeta) as Category[]).map((category) => (
              <Link
                key={category}
                to={`/category/${category}`}
                className="group border border-green-900/15 bg-white px-5 py-6 transition hover:-translate-y-1 hover:border-orange-500 dark:border-green-50/15 dark:bg-[#0d1d17]"
              >
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-green-100 font-bold text-green-900 dark:bg-green-900/50 dark:text-green-100">
                  {categoryMeta[category].icon}
                </span>
                <h3 className="mt-4 text-xl font-semibold text-green-950 group-hover:text-orange-600 dark:text-green-50 dark:group-hover:text-orange-300">
                  {categoryMeta[category].title}
                </h3>
                <p className="mt-2 text-sm text-green-900/75 dark:text-green-100/75">{categoryMeta[category].note}</p>
              </Link>
            ))}
          </div>
        </motion.section>

        <motion.section {...sectionMotion}>
          <h2 className="text-3xl font-bold text-green-950 dark:text-green-50">Best Picks of the Week</h2>
          <div className="mt-7 grid gap-6 md:grid-cols-3">
            {bestPicks.map((item) => (
              <Link key={item.id} to={`/product/${item.id}`} className="group border border-green-900/15 p-4 transition hover:border-orange-500 dark:border-green-50/15">
                <img src={item.images[0]} alt={item.title} className="h-52 w-full object-cover" loading="lazy" decoding="async" />
                <h3 className="mt-4 text-lg font-semibold text-green-950 transition group-hover:text-orange-600 dark:text-green-50 dark:group-hover:text-orange-300">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm text-green-900/80 dark:text-green-100/85">{item.summary}</p>
              </Link>
            ))}
          </div>
        </motion.section>

        <motion.section {...sectionMotion}>
          <h2 className="text-3xl font-bold text-green-950 dark:text-green-50">Product Comparison Tool</h2>
          <p className="mt-2 text-green-900/75 dark:text-green-100/80">Compare two products side-by-side.</p>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <select
              value={compareA}
              onChange={(event) => setCompareA(event.target.value)}
              className="h-11 border border-green-900/25 bg-white px-3 text-sm text-green-950 dark:border-green-50/20 dark:bg-[#10271d] dark:text-green-50"
            >
              {publishedArticles.map((item) => (
                <option key={`a-${item.id}`} value={item.id}>
                  {item.title}
                </option>
              ))}
            </select>
            <select
              value={compareB}
              onChange={(event) => setCompareB(event.target.value)}
              className="h-11 border border-green-900/25 bg-white px-3 text-sm text-green-950 dark:border-green-50/20 dark:bg-[#10271d] dark:text-green-50"
            >
              {publishedArticles.map((item) => (
                <option key={`b-${item.id}`} value={item.id}>
                  {item.title}
                </option>
              ))}
            </select>
          </div>
          {a && b && (
            <div className="mt-6 overflow-x-auto border border-green-900/15 dark:border-green-50/15">
              <table className="min-w-full text-left text-sm">
                <thead className="bg-green-100/60 dark:bg-green-900/30">
                  <tr>
                    <th className="px-4 py-3">Metric</th>
                    <th className="px-4 py-3">{a.title}</th>
                    <th className="px-4 py-3">{b.title}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-green-900/10 dark:divide-green-50/10">
                  <tr>
                    <td className="px-4 py-3">Rating</td>
                    <td className="px-4 py-3">{stars(a.rating)}</td>
                    <td className="px-4 py-3">{stars(b.rating)}</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Price</td>
                    <td className="px-4 py-3">{formatPrice(a.price)}</td>
                    <td className="px-4 py-3">{formatPrice(b.price)}</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3">Durability</td>
                    <td className="px-4 py-3">{a.durability.toFixed(1)}</td>
                    <td className="px-4 py-3">{b.durability.toFixed(1)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </motion.section>

        <motion.section {...sectionMotion} className="border border-green-900/15 bg-green-50 p-8 dark:border-green-50/10 dark:bg-[#11251c]">
          <h2 className="text-2xl font-bold text-green-950 dark:text-green-50">Newsletter</h2>
          <p className="mt-2 text-sm text-green-900/80 dark:text-green-100/80">Get weekly review drops and buying guides.</p>
          <form className="mt-5 flex max-w-lg flex-col gap-3 sm:flex-row" onSubmit={(event) => event.preventDefault()}>
            <input
              type="email"
              required
              placeholder="Enter your email"
              className="h-11 flex-1 border border-green-900/20 bg-white px-3 text-sm text-green-950 outline-none ring-orange-300 focus:ring-2 dark:border-green-50/20 dark:bg-[#0d1d17] dark:text-green-50"
            />
            <button className="h-11 bg-orange-500 px-5 text-sm font-semibold text-white transition hover:bg-orange-400">Subscribe</button>
          </form>
        </motion.section>
      </main>
    </>
  );
}

function CategoryPage({
  siteTitle,
  search,
  setSearch,
  publishedArticles,
}: {
  siteTitle: string;
  search: string;
  setSearch: (value: string) => void;
  publishedArticles: Article[];
}) {
  const navigate = useNavigate();
  const params = useParams<{ slug: Category }>();
  const slug = params.slug as Category | undefined;

  const validSlug = Boolean(slug && slug in categoryMeta);
  const categorySlug: Category = validSlug ? (slug as Category) : "home";

  usePageMeta(
    `${categoryMeta[categorySlug].title} Reviews | ${siteTitle}`,
    `Browse ${categoryMeta[categorySlug].title.toLowerCase()} product reviews with ratings, price checks, and buying links.`
  );

  const [minRating, setMinRating] = useState(4);
  const [maxPrice, setMaxPrice] = useState(250);

  const visible = useMemo(() => {
    return publishedArticles.filter((item) => {
      const query = search.toLowerCase();
      const matchesCategory = item.category === categorySlug;
      const matchesQuery = !query || `${item.title} ${item.summary}`.toLowerCase().includes(query);
      return matchesCategory && matchesQuery && item.rating >= minRating && item.price <= maxPrice;
    });
  }, [publishedArticles, categorySlug, minRating, maxPrice, search]);

  if (!validSlug) {
    return <Navigate to="/category/home" replace />;
  }

  return (
    <main className="mx-auto w-full max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl font-bold text-green-950 dark:text-green-50">{categoryMeta[categorySlug].title} Product Reviews</h1>
          <p className="mt-3 max-w-2xl text-green-900/80 dark:text-green-100/80">{categoryMeta[categorySlug].note}</p>
        </div>
        <select
          value={categorySlug}
          onChange={(event) => navigate(`/category/${event.target.value}`)}
          className="h-11 border border-green-900/25 bg-white px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
        >
          {(Object.keys(categoryMeta) as Category[]).map((category) => (
            <option key={category} value={category}>
              {categoryMeta[category].title}
            </option>
          ))}
        </select>
      </div>

      <section className="mt-8 grid gap-4 border border-green-900/15 p-4 md:grid-cols-2 lg:grid-cols-4 dark:border-green-50/15">
        <label className="text-sm text-green-900 dark:text-green-100">
          Search
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search this category"
            className="mt-1 h-10 w-full border border-green-900/20 bg-green-50 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
        </label>
        <label className="text-sm text-green-900 dark:text-green-100">
          Min rating
          <input
            type="range"
            min={3}
            max={5}
            step={0.1}
            value={minRating}
            onChange={(event) => setMinRating(Number(event.target.value))}
            className="mt-1 h-10 w-full"
          />
          <span className="text-xs">{minRating.toFixed(1)}+</span>
        </label>
        <label className="text-sm text-green-900 dark:text-green-100">
          Max price
          <input
            type="range"
            min={40}
            max={300}
            step={5}
            value={maxPrice}
            onChange={(event) => setMaxPrice(Number(event.target.value))}
            className="mt-1 h-10 w-full"
          />
          <span className="text-xs">Up to {formatPrice(maxPrice)}</span>
        </label>
        <div className="flex items-end">
          <button
            onClick={() => {
              setMinRating(4);
              setMaxPrice(250);
            }}
            className="h-10 w-full border border-green-900/25 text-sm font-semibold text-green-900 transition hover:bg-green-900 hover:text-white dark:border-green-50/25 dark:text-green-50 dark:hover:bg-green-100 dark:hover:text-green-950"
          >
            Reset filters
          </button>
        </div>
      </section>

      <section className="mt-8 divide-y divide-green-900/10 dark:divide-green-50/10">
        {visible.length > 0 ? (
          visible.map((item) => <ProductRow key={item.id} article={item} />)
        ) : (
          <p className="py-12 text-center text-green-900/80 dark:text-green-100/80">No products match your current filters.</p>
        )}
      </section>
    </main>
  );
}

function ProductPage({
  siteTitle,
  publishedArticles,
  onTrackView,
}: {
  siteTitle: string;
  publishedArticles: Article[];
  onTrackView: (id: string) => void;
}) {
  const { id } = useParams<{ id: string }>();
  const article = publishedArticles.find((item) => item.id === id);
  const [activeImage, setActiveImage] = useState(0);
  const [comments, setComments] = useState<string[]>([
    "Very useful review. It helped me shortlist quickly.",
    "Can you add an update about long-term durability after a few months?",
  ]);
  const [newComment, setNewComment] = useState("");

  useEffect(() => {
    setActiveImage(0);
  }, [id]);

  useEffect(() => {
    if (article) {
      onTrackView(article.id);
    }
  }, [article, onTrackView]);

  usePageMeta(
    article ? `${article.title} Review | ${siteTitle}` : `Product Review | ${siteTitle}`,
    article
      ? `${article.title} detailed review with rating breakdown, pros and cons, and direct buy links.`
      : "Read full product reviews with ratings and buying links."
  );

  if (!article) {
    return <Navigate to="/" replace />;
  }

  const related = publishedArticles.filter((item) => item.category === article.category && item.id !== article.id).slice(0, 3);

  const submitComment = (event: FormEvent) => {
    event.preventDefault();
    const value = newComment.trim();
    if (!value) {
      return;
    }
    setComments((prev) => [value, ...prev]);
    setNewComment("");
  };

  const pageUrl = encodeURIComponent(window.location.href);
  const shareText = encodeURIComponent(`Check this review: ${article.title}`);

  return (
    <main className="mx-auto w-full max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <article className="space-y-10">
        <header className="space-y-4">
          <h1 className="text-4xl font-bold text-green-950 dark:text-green-50">{article.title}</h1>
          <p className="text-base text-green-900/85 dark:text-green-100/85">{article.summary}</p>
          <div className="flex flex-wrap gap-4 text-sm text-green-900 dark:text-green-100">
            <span>{stars(article.rating)}</span>
            <span>{formatPrice(article.price)}</span>
            <span>{categoryMeta[article.category].title}</span>
          </div>
        </header>

        <section className="grid gap-4 lg:grid-cols-[1fr_180px]">
          <img src={article.images[activeImage]} alt={`${article.title} view ${activeImage + 1}`} className="h-[440px] w-full object-cover" />
          <div className="grid grid-cols-3 gap-3 lg:grid-cols-1">
            {article.images.map((image, index) => (
              <button key={image} onClick={() => setActiveImage(index)} className="h-24 overflow-hidden border border-green-900/20 dark:border-green-50/20">
                <img src={image} alt={`${article.title} thumbnail ${index + 1}`} className="h-full w-full object-cover" loading="lazy" decoding="async" />
              </button>
            ))}
          </div>
        </section>

        <section className="grid gap-8 lg:grid-cols-[1.5fr_1fr]">
          <div>
            <h2 className="text-2xl font-semibold text-green-950 dark:text-green-50">Detailed Review</h2>
            <div className="prose mt-3 max-w-none prose-p:text-green-900/85 dark:prose-invert" dangerouslySetInnerHTML={{ __html: article.content }} />
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <div>
                <h3 className="font-semibold text-green-950 dark:text-green-50">Pros</h3>
                <ul className="mt-2 space-y-1 text-sm text-green-900/85 dark:text-green-100/85">
                  {article.pros.map((pro) => (
                    <li key={pro}>+ {pro}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-green-950 dark:text-green-50">Cons</h3>
                <ul className="mt-2 space-y-1 text-sm text-green-900/85 dark:text-green-100/85">
                  {article.cons.map((con) => (
                    <li key={con}>- {con}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <aside className="space-y-6 border border-green-900/15 p-5 dark:border-green-50/15">
            <h3 className="text-lg font-semibold text-green-950 dark:text-green-50">Rating Breakdown</h3>
            {[
              ["quality", article.quality],
              ["value", article.value],
              ["durability", article.durability],
            ].map(([label, score]) => (
              <div key={label}>
                <div className="mb-1 flex justify-between text-sm text-green-900 dark:text-green-100">
                  <span className="capitalize">{label}</span>
                  <span>{Number(score).toFixed(1)}</span>
                </div>
                <div className="h-2 bg-green-100 dark:bg-green-900/50">
                  <div className="h-full bg-orange-500" style={{ width: `${(Number(score) / 5) * 100}%` }} />
                </div>
              </div>
            ))}
            <div className="space-y-3 pt-2 text-sm font-semibold">
              <a href={article.amazonUrl} target="_blank" rel="noreferrer" className="block bg-green-900 px-4 py-2 text-center text-white transition hover:bg-green-800">
                Buy on Amazon
              </a>
              <a
                href={article.temuUrl}
                target="_blank"
                rel="noreferrer"
                className="block border border-orange-500 px-4 py-2 text-center text-orange-700 transition hover:bg-orange-500 hover:text-white dark:border-orange-300 dark:text-orange-200 dark:hover:bg-orange-300 dark:hover:text-green-950"
              >
                Buy on Temu
              </a>
            </div>
            <div>
              <h4 className="mb-2 text-sm font-semibold text-green-950 dark:text-green-50">Share this review</h4>
              <div className="flex flex-wrap gap-2 text-xs">
                <a className="border border-green-900/25 px-3 py-1 transition hover:bg-green-900 hover:text-white dark:border-green-50/30" target="_blank" rel="noreferrer" href={`https://twitter.com/intent/tweet?text=${shareText}&url=${pageUrl}`}>
                  X
                </a>
                <a className="border border-green-900/25 px-3 py-1 transition hover:bg-green-900 hover:text-white dark:border-green-50/30" target="_blank" rel="noreferrer" href={`https://www.facebook.com/sharer/sharer.php?u=${pageUrl}`}>
                  Facebook
                </a>
                <a className="border border-green-900/25 px-3 py-1 transition hover:bg-green-900 hover:text-white dark:border-green-50/30" target="_blank" rel="noreferrer" href={`https://pinterest.com/pin/create/button/?url=${pageUrl}&description=${shareText}`}>
                  Pinterest
                </a>
              </div>
            </div>
          </aside>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-green-950 dark:text-green-50">Related Products</h2>
          <div className="mt-5 grid gap-5 md:grid-cols-3">
            {related.map((item) => (
              <Link key={item.id} to={`/product/${item.id}`} className="border border-green-900/15 p-3 transition hover:border-orange-500 dark:border-green-50/15">
                <img src={item.images[0]} alt={item.title} className="h-40 w-full object-cover" loading="lazy" decoding="async" />
                <h3 className="mt-3 font-semibold text-green-950 dark:text-green-50">{item.title}</h3>
                <p className="mt-1 text-sm text-green-900/80 dark:text-green-100/80">{stars(item.rating)}</p>
              </Link>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-green-950 dark:text-green-50">Discussion</h2>
          <form onSubmit={submitComment} className="mt-4 flex flex-col gap-3 sm:flex-row">
            <input
              value={newComment}
              onChange={(event) => setNewComment(event.target.value)}
              placeholder="Share your experience with this product"
              className="h-11 flex-1 border border-green-900/25 bg-white px-3 text-sm outline-none ring-orange-300 focus:ring-2 dark:border-green-50/20 dark:bg-[#10271d]"
            />
            <button className="h-11 bg-orange-500 px-5 text-sm font-semibold text-white transition hover:bg-orange-400">Post</button>
          </form>
          <div className="mt-5 space-y-3">
            {comments.map((comment, index) => (
              <p key={`${comment}-${index}`} className="border border-green-900/15 p-3 text-sm text-green-900/85 dark:border-green-50/15 dark:text-green-100/85">
                {comment}
              </p>
            ))}
          </div>
        </section>
      </article>
    </main>
  );
}

function AboutPage({ siteTitle }: { siteTitle: string }) {
  usePageMeta(
    `About ${siteTitle} | Transparent Methodology and Trust`,
    `Learn who we are, how we review products, and why shoppers trust ${siteTitle}.`
  );

  return (
    <main className="mx-auto w-full max-w-5xl space-y-10 px-4 py-10 sm:px-6 lg:px-8">
      <section>
        <h1 className="text-4xl font-bold text-green-950 dark:text-green-50">Who We Are</h1>
        <p className="mt-4 leading-relaxed text-green-900/85 dark:text-green-100/85">
          We are an independent review team focused on practical products for daily life. Every review is written after scenario-based testing in homes, kitchens, and gardens.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-green-950 dark:text-green-50">Our Review Methodology</h2>
        <p className="mt-3 leading-relaxed text-green-900/85 dark:text-green-100/85">
          We score each product using quality, value, and durability. Each review includes transparent pros and cons, realistic tradeoffs, and direct alternatives in the same price range.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-green-950 dark:text-green-50">Trust Badges</h2>
        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          {["Hands-on Tested", "Affiliate Disclosure", "Updated Weekly"].map((badge) => (
            <div key={badge} className="border border-green-900/15 p-5 text-center dark:border-green-50/15">
              <p className="font-semibold text-green-950 dark:text-green-50">{badge}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}

function ContactPage({
  siteTitle,
  socialLinks,
  onSubmitMessage,
}: {
  siteTitle: string;
  socialLinks: SiteSettings["socialLinks"];
  onSubmitMessage: (payload: Omit<ContactMessage, "id" | "read" | "createdAt">) => void;
}) {
  usePageMeta(
    `Contact ${siteTitle} | Questions, Feedback, Partnerships`,
    `Reach the ${siteTitle} team with your product questions, feedback, and collaboration requests.`
  );

  const [openFAQ, setOpenFAQ] = useState<string | null>("How do you select products?");
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  const faq = [
    {
      q: "How do you select products?",
      a: "We prioritize products with high demand, strong value potential, and clear use-cases across Home, Cuisine, and Garden.",
    },
    {
      q: "Do affiliate links affect your reviews?",
      a: "No. Revenue does not change our scores. Pros and cons are published transparently for every review.",
    },
    {
      q: "Can I request a product review?",
      a: "Yes. Submit a request with product category and target budget so our team can evaluate it.",
    },
  ];

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!form.name || !form.email || !form.subject || !form.message) {
      return;
    }
    onSubmitMessage(form);
    setForm({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <main className="mx-auto w-full max-w-6xl space-y-10 px-4 py-10 sm:px-6 lg:px-8">
      <section className="grid gap-8 lg:grid-cols-2">
        <div>
          <h1 className="text-4xl font-bold text-green-950 dark:text-green-50">Contact Us</h1>
          <p className="mt-3 text-green-900/85 dark:text-green-100/85">We usually reply within 24-48 hours.</p>
          <form className="mt-6 space-y-3" onSubmit={submit}>
            <input
              required
              placeholder="Name"
              value={form.name}
              onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
              className="h-11 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            />
            <input
              required
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))}
              className="h-11 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            />
            <input
              required
              placeholder="Subject"
              value={form.subject}
              onChange={(event) => setForm((prev) => ({ ...prev, subject: event.target.value }))}
              className="h-11 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            />
            <textarea
              required
              placeholder="Message"
              value={form.message}
              onChange={(event) => setForm((prev) => ({ ...prev, message: event.target.value }))}
              className="min-h-36 w-full border border-green-900/20 p-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            />
            <button className="h-11 bg-orange-500 px-5 text-sm font-semibold text-white transition hover:bg-orange-400">Send Message</button>
          </form>
        </div>
        <div>
          <h2 className="text-2xl font-semibold text-green-950 dark:text-green-50">Social Links</h2>
          <div className="mt-4 flex gap-3 text-sm">
            {[
              ["Instagram", socialLinks.instagram],
              ["YouTube", socialLinks.youtube],
              ["X", socialLinks.x],
            ].map(([label, href]) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noreferrer"
                className="border border-green-900/25 px-4 py-2 transition hover:bg-green-900 hover:text-white dark:border-green-50/25 dark:hover:bg-green-100 dark:hover:text-green-950"
              >
                {label}
              </a>
            ))}
          </div>

          <h2 className="mt-8 text-2xl font-semibold text-green-950 dark:text-green-50">FAQ</h2>
          <div className="mt-4 divide-y divide-green-900/10 border-y border-green-900/10 dark:divide-green-50/10 dark:border-green-50/10">
            {faq.map((item) => (
              <div key={item.q}>
                <button
                  onClick={() => setOpenFAQ((prev) => (prev === item.q ? null : item.q))}
                  className="flex w-full items-center justify-between py-4 text-left text-sm font-semibold text-green-900 dark:text-green-100"
                >
                  {item.q}
                  <span>{openFAQ === item.q ? "-" : "+"}</span>
                </button>
                <AnimatePresence>
                  {openFAQ === item.q && (
                    <motion.p
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden pb-4 text-sm text-green-900/80 dark:text-green-100/80"
                    >
                      {item.a}
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

function AdminLoginPage({
  isAuthenticated,
  credentials,
  onLogin,
  siteTitle,
}: {
  isAuthenticated: boolean;
  credentials: AdminCredentials;
  onLogin: (email: string, password: string) => boolean;
  siteTitle: string;
}) {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  usePageMeta(`Admin Login | ${siteTitle}`, `Secure admin login for ${siteTitle} CMS dashboard.`);

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/admin", { replace: true });
    }
  }, [isAuthenticated, navigate]);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const ok = onLogin(form.email, form.password);
    if (ok) {
      navigate("/admin", { replace: true });
      return;
    }
    setError(`Invalid credentials. Default email is ${credentials.email}`);
  };

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-md items-center px-4 py-12">
      <form onSubmit={submit} className="w-full border border-green-900/15 bg-white p-6 dark:border-green-50/15 dark:bg-[#0d1d17]">
        <h1 className="text-2xl font-bold text-green-950 dark:text-green-50">Admin Login</h1>
        <p className="mt-2 text-sm text-green-900/80 dark:text-green-100/80">Sign in to manage reviews, media, and settings.</p>
        <div className="mt-5 space-y-3">
          <input
            type="email"
            required
            placeholder="Email"
            value={form.email}
            onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))}
            className="h-11 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <input
            type="password"
            required
            placeholder="Password"
            value={form.password}
            onChange={(event) => setForm((prev) => ({ ...prev, password: event.target.value }))}
            className="h-11 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          {error && <p className="text-xs text-orange-600 dark:text-orange-300">{error}</p>}
          <button className="h-11 w-full bg-green-900 text-sm font-semibold text-white transition hover:bg-green-800">Login</button>
        </div>
      </form>
    </main>
  );
}

function ProtectedAdminRoute({ isAuthenticated, children }: { isAuthenticated: boolean; children: ReactElement }) {
  if (!isAuthenticated) {
    return <Navigate to="/admin/login" replace />;
  }
  return children;
}

function AdminLayout({ onLogout }: { onLogout: () => void }) {
  const items = [
    { to: "/admin", label: "Dashboard" },
    { to: "/admin/articles", label: "Articles" },
    { to: "/admin/media", label: "Media" },
    { to: "/admin/messages", label: "Contact Messages" },
    { to: "/admin/settings", label: "Settings" },
  ];

  return (
    <div className="min-h-screen bg-[#f6fbf8] text-green-950 dark:bg-[#08140f] dark:text-green-50">
      <div className="mx-auto grid w-full max-w-7xl gap-6 px-4 py-6 lg:grid-cols-[220px_1fr] sm:px-6 lg:px-8">
        <aside className="border border-green-900/15 bg-white p-4 dark:border-green-50/15 dark:bg-[#0d1d17]">
          <Link to="/" className="text-sm font-semibold text-orange-600 dark:text-orange-300">
            Back to Site
          </Link>
          <nav className="mt-4 space-y-1">
            {items.map((item) => (
              <NavLink
                key={item.to}
                end={item.to === "/admin"}
                to={item.to}
                className={({ isActive }) =>
                  `block px-3 py-2 text-sm ${
                    isActive
                      ? "bg-green-900 text-white dark:bg-green-100 dark:text-green-950"
                      : "text-green-900 hover:bg-green-100 dark:text-green-100 dark:hover:bg-green-900/40"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>
          <button
            onClick={onLogout}
            className="mt-6 w-full border border-orange-500 px-3 py-2 text-sm text-orange-700 transition hover:bg-orange-500 hover:text-white dark:border-orange-300 dark:text-orange-200"
          >
            Logout
          </button>
        </aside>
        <main className="border border-green-900/15 bg-white p-6 dark:border-green-50/15 dark:bg-[#0d1d17]">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function AdminDashboardHome({ articles, siteVisits }: { articles: Article[]; siteVisits: number }) {
  const recent = articles.slice().sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt)).slice(0, 5);
  const totalViews = articles.reduce((sum, item) => sum + item.views, 0);

  return (
    <section className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-green-950 dark:text-green-50">CMS Dashboard</h1>
        <p className="mt-2 text-sm text-green-900/80 dark:text-green-100/80">Manage content, media, and site operations.</p>
      </header>

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="border border-green-900/15 p-4 dark:border-green-50/15">
          <p className="text-xs uppercase tracking-wide text-green-900/70 dark:text-green-100/70">Total articles</p>
          <p className="mt-2 text-3xl font-bold">{articles.length}</p>
        </div>
        <div className="border border-green-900/15 p-4 dark:border-green-50/15">
          <p className="text-xs uppercase tracking-wide text-green-900/70 dark:text-green-100/70">Total views</p>
          <p className="mt-2 text-3xl font-bold">{totalViews.toLocaleString()}</p>
        </div>
        <div className="border border-green-900/15 p-4 dark:border-green-50/15">
          <p className="text-xs uppercase tracking-wide text-green-900/70 dark:text-green-100/70">Site visits</p>
          <p className="mt-2 text-3xl font-bold">{siteVisits.toLocaleString()}</p>
        </div>
      </div>

      <section>
        <div className="mb-4 flex flex-wrap gap-3">
          <Link to="/admin/articles/new" className="bg-green-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-green-800">
            Add New Article
          </Link>
          <Link to="/admin/articles" className="border border-green-900/25 px-4 py-2 text-sm font-semibold text-green-900 transition hover:bg-green-900 hover:text-white dark:border-green-50/30 dark:text-green-50">
            Edit / Delete Articles
          </Link>
        </div>
        <h2 className="text-xl font-semibold text-green-950 dark:text-green-50">Recent Articles</h2>
        <div className="mt-3 divide-y divide-green-900/10 border border-green-900/10 dark:divide-green-50/10 dark:border-green-50/10">
          {recent.map((item) => (
            <div key={item.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 text-sm">
              <p>{item.title}</p>
              <p className="text-green-900/70 dark:text-green-100/75">{new Date(item.updatedAt).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      </section>
    </section>
  );
}

function AdminArticlesPage({
  articles,
  onDelete,
}: {
  articles: Article[];
  onDelete: (id: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<"all" | Category>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | ArticleStatus>("all");

  const filtered = useMemo(() => {
    return articles.filter((item) => {
      const byQuery = !query || `${item.title} ${item.summary}`.toLowerCase().includes(query.toLowerCase());
      const byCategory = categoryFilter === "all" || item.category === categoryFilter;
      const byStatus = statusFilter === "all" || item.status === statusFilter;
      return byQuery && byCategory && byStatus;
    });
  }, [articles, query, categoryFilter, statusFilter]);

  return (
    <section className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <h1 className="text-3xl font-bold text-green-950 dark:text-green-50">Article Management</h1>
        <Link to="/admin/articles/new" className="bg-green-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-green-800">
          Create New Review
        </Link>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search articles"
          className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
        />
        <select
          value={categoryFilter}
          onChange={(event) => setCategoryFilter(event.target.value as "all" | Category)}
          className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
        >
          <option value="all">All categories</option>
          {(Object.keys(categoryMeta) as Category[]).map((category) => (
            <option key={category} value={category}>
              {categoryMeta[category].title}
            </option>
          ))}
        </select>
        <select
          value={statusFilter}
          onChange={(event) => setStatusFilter(event.target.value as "all" | ArticleStatus)}
          className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
        >
          <option value="all">All statuses</option>
          <option value="Draft">Draft</option>
          <option value="Published">Published</option>
        </select>
      </div>

      <div className="overflow-x-auto border border-green-900/15 dark:border-green-50/15">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-green-100/60 dark:bg-green-900/30">
            <tr>
              <th className="px-4 py-3">Title</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Rating</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-green-900/10 dark:divide-green-50/10">
            {filtered.map((item) => (
              <tr key={item.id}>
                <td className="px-4 py-3">{item.title}</td>
                <td className="px-4 py-3">{categoryMeta[item.category].title}</td>
                <td className="px-4 py-3">{item.rating.toFixed(1)}</td>
                <td className="px-4 py-3">{formatPrice(item.price)}</td>
                <td className="px-4 py-3">{item.status}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <Link to={`/admin/articles/${item.id}/edit`} className="border border-green-900/25 px-3 py-1 text-xs dark:border-green-50/25">
                      Edit
                    </Link>
                    <button
                      onClick={() => onDelete(item.id)}
                      className="border border-orange-500 px-3 py-1 text-xs text-orange-700 dark:border-orange-300 dark:text-orange-200"
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function RichTextEditor({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const editorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== value) {
      editorRef.current.innerHTML = value;
    }
  }, [value]);

  const command = (cmd: string, arg?: string) => {
    document.execCommand(cmd, false, arg);
    onChange(editorRef.current?.innerHTML ?? "");
  };

  return (
    <div className="border border-green-900/20 dark:border-green-50/20">
      <div className="flex flex-wrap gap-2 border-b border-green-900/20 bg-green-50 p-2 dark:border-green-50/20 dark:bg-[#10271d]">
        {[
          ["B", "bold"],
          ["I", "italic"],
          ["UL", "insertUnorderedList"],
          ["OL", "insertOrderedList"],
        ].map(([label, cmd]) => (
          <button key={cmd} type="button" onClick={() => command(cmd)} className="border border-green-900/25 px-2 py-1 text-xs dark:border-green-50/25">
            {label}
          </button>
        ))}
        <button type="button" onClick={() => command("formatBlock", "h3")} className="border border-green-900/25 px-2 py-1 text-xs dark:border-green-50/25">
          H3
        </button>
      </div>
      <div
        ref={editorRef}
        contentEditable
        suppressContentEditableWarning
        onInput={() => onChange(editorRef.current?.innerHTML ?? "")}
        className="min-h-44 p-3 text-sm outline-none"
      />
    </div>
  );
}

function AdminArticleEditorPage({
  articles,
  media,
  onSave,
  onAddMedia,
}: {
  articles: Article[];
  media: MediaItem[];
  onSave: (article: Article) => void;
  onAddMedia: (items: { name: string; url: string }[]) => MediaItem[];
}) {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const editing = Boolean(id);
  const existing = articles.find((item) => item.id === id);

  const [form, setForm] = useState<Article>(
    existing ?? {
      id: "",
      title: "",
      category: "home",
      images: [],
      content: "<p>Write your review here...</p>",
      summary: "",
      rating: 4,
      pros: [],
      cons: [],
      amazonUrl: "https://www.amazon.com/",
      temuUrl: "https://www.temu.com/",
      price: 99,
      quality: 4,
      value: 4,
      durability: 4,
      status: "Draft",
      views: 0,
      updatedAt: nowISO(),
    }
  );
  const [prosInput, setProsInput] = useState(existing?.pros.join(", ") ?? "");
  const [consInput, setConsInput] = useState(existing?.cons.join(", ") ?? "");

  useEffect(() => {
    if (editing && !existing) {
      navigate("/admin/articles", { replace: true });
    }
  }, [editing, existing, navigate]);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!form.title.trim() || form.images.length === 0) {
      return;
    }
    const articleId = editing ? form.id : slugify(form.title) || `article-${Date.now()}`;
    onSave({
      ...form,
      id: articleId,
      summary: form.summary || stripHtml(form.content).slice(0, 160),
      pros: prosInput.split(",").map((item) => item.trim()).filter(Boolean),
      cons: consInput.split(",").map((item) => item.trim()).filter(Boolean),
      updatedAt: nowISO(),
    });
    navigate("/admin/articles");
  };

  const uploadImages = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files || event.target.files.length === 0) {
      return;
    }
    const files = await filesToDataUrls(event.target.files);
    const added = onAddMedia(files);
    setForm((prev) => ({ ...prev, images: [...new Set([...prev.images, ...added.map((item) => item.url)])] }));
    event.target.value = "";
  };

  return (
    <section>
      <h1 className="text-3xl font-bold text-green-950 dark:text-green-50">{editing ? "Edit Article" : "Create New Article"}</h1>
      <form onSubmit={submit} className="mt-6 space-y-4">
        <div className="grid gap-3 md:grid-cols-2">
          <input
            required
            value={form.title}
            onChange={(event) => setForm((prev) => ({ ...prev, title: event.target.value }))}
            placeholder="Title"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <select
            value={form.category}
            onChange={(event) => setForm((prev) => ({ ...prev, category: event.target.value as Category }))}
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          >
            {(Object.keys(categoryMeta) as Category[]).map((category) => (
              <option key={category} value={category}>
                {categoryMeta[category].title}
              </option>
            ))}
          </select>
        </div>

        <div className="grid gap-3 md:grid-cols-3">
          <label className="text-sm">
            Rating (1-5)
            <input
              type="number"
              min={1}
              max={5}
              step={0.1}
              value={form.rating}
              onChange={(event) => setForm((prev) => ({ ...prev, rating: Number(event.target.value) }))}
              className="mt-1 h-10 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            />
          </label>
          <label className="text-sm">
            Price
            <input
              type="number"
              min={1}
              value={form.price}
              onChange={(event) => setForm((prev) => ({ ...prev, price: Number(event.target.value) }))}
              className="mt-1 h-10 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            />
          </label>
          <label className="text-sm">
            Status
            <select
              value={form.status}
              onChange={(event) => setForm((prev) => ({ ...prev, status: event.target.value as ArticleStatus }))}
              className="mt-1 h-10 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            >
              <option value="Draft">Draft</option>
              <option value="Published">Published</option>
            </select>
          </label>
        </div>

        <textarea
          value={form.summary}
          onChange={(event) => setForm((prev) => ({ ...prev, summary: event.target.value }))}
          placeholder="Short review summary"
          className="min-h-24 w-full border border-green-900/20 p-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
        />

        <div>
          <p className="mb-2 text-sm font-semibold">Review content (rich text editor)</p>
          <RichTextEditor value={form.content} onChange={(content) => setForm((prev) => ({ ...prev, content }))} />
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <input
            value={prosInput}
            onChange={(event) => setProsInput(event.target.value)}
            placeholder="Pros (comma separated)"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <input
            value={consInput}
            onChange={(event) => setConsInput(event.target.value)}
            placeholder="Cons (comma separated)"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <input
            value={form.amazonUrl}
            onChange={(event) => setForm((prev) => ({ ...prev, amazonUrl: event.target.value }))}
            placeholder="Amazon link"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <input
            value={form.temuUrl}
            onChange={(event) => setForm((prev) => ({ ...prev, temuUrl: event.target.value }))}
            placeholder="Temu link"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
        </div>

        <div className="grid gap-3 md:grid-cols-3">
          <label className="text-sm">
            Quality
            <input
              type="number"
              min={1}
              max={5}
              step={0.1}
              value={form.quality}
              onChange={(event) => setForm((prev) => ({ ...prev, quality: Number(event.target.value) }))}
              className="mt-1 h-10 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            />
          </label>
          <label className="text-sm">
            Value
            <input
              type="number"
              min={1}
              max={5}
              step={0.1}
              value={form.value}
              onChange={(event) => setForm((prev) => ({ ...prev, value: Number(event.target.value) }))}
              className="mt-1 h-10 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            />
          </label>
          <label className="text-sm">
            Durability
            <input
              type="number"
              min={1}
              max={5}
              step={0.1}
              value={form.durability}
              onChange={(event) => setForm((prev) => ({ ...prev, durability: Number(event.target.value) }))}
              className="mt-1 h-10 w-full border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
            />
          </label>
        </div>

        <div className="space-y-3 border border-green-900/15 p-4 dark:border-green-50/15">
          <p className="text-sm font-semibold">Product images upload</p>
          <input type="file" accept="image/*" multiple onChange={uploadImages} className="text-sm" />
          <div className="grid gap-3 sm:grid-cols-4">
            {media.slice(0, 12).map((item) => (
              <button
                type="button"
                key={item.id}
                onClick={() => setForm((prev) => ({ ...prev, images: [...new Set([...prev.images, item.url])] }))}
                className="border border-green-900/20 p-1 dark:border-green-50/20"
              >
                <img src={item.url} alt={item.name} className="h-20 w-full object-cover" loading="lazy" />
              </button>
            ))}
          </div>
          {form.images.length > 0 && (
            <div className="grid gap-2 sm:grid-cols-5">
              {form.images.map((image) => (
                <div key={image} className="relative border border-green-900/20 p-1 dark:border-green-50/20">
                  <img src={image} alt="Selected" className="h-16 w-full object-cover" loading="lazy" />
                  <button
                    type="button"
                    onClick={() => setForm((prev) => ({ ...prev, images: prev.images.filter((item) => item !== image) }))}
                    className="absolute right-1 top-1 bg-white px-1 text-xs text-red-600"
                  >
                    x
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-3">
          <button className="bg-green-900 px-5 py-2 text-sm font-semibold text-white transition hover:bg-green-800">Save Article</button>
          <button type="button" onClick={() => navigate("/admin/articles")} className="border border-green-900/25 px-5 py-2 text-sm font-semibold text-green-900 dark:border-green-50/30 dark:text-green-50">
            Cancel
          </button>
        </div>
      </form>
    </section>
  );
}

function AdminMediaManagerPage({
  media,
  onAdd,
  onDelete,
}: {
  media: MediaItem[];
  onAdd: (items: { name: string; url: string }[]) => void;
  onDelete: (id: string) => void;
}) {
  const upload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files || event.target.files.length === 0) {
      return;
    }
    const files = await filesToDataUrls(event.target.files);
    onAdd(files);
    event.target.value = "";
  };

  return (
    <section className="space-y-5">
      <h1 className="text-3xl font-bold text-green-950 dark:text-green-50">Media Manager</h1>
      <label className="inline-flex cursor-pointer border border-green-900/25 px-4 py-2 text-sm font-semibold text-green-900 dark:border-green-50/30 dark:text-green-50">
        Upload product images
        <input type="file" accept="image/*" multiple onChange={upload} className="hidden" />
      </label>
      <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {media.map((item) => (
          <div key={item.id} className="border border-green-900/15 p-2 dark:border-green-50/15">
            <img src={item.url} alt={item.name} className="h-36 w-full object-cover" loading="lazy" />
            <p className="mt-2 truncate text-xs text-green-900/75 dark:text-green-100/75">{item.name}</p>
            <button onClick={() => onDelete(item.id)} className="mt-2 w-full border border-orange-500 px-2 py-1 text-xs text-orange-700 dark:border-orange-300 dark:text-orange-200">
              Delete
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}

function AdminMessagesPage({
  messages,
  onToggleRead,
  onDelete,
}: {
  messages: ContactMessage[];
  onToggleRead: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <section className="space-y-5">
      <h1 className="text-3xl font-bold text-green-950 dark:text-green-50">Contact Messages</h1>
      <div className="divide-y divide-green-900/10 border border-green-900/10 dark:divide-green-50/10 dark:border-green-50/10">
        {messages.length === 0 && <p className="p-4 text-sm text-green-900/75 dark:text-green-100/75">No messages yet.</p>}
        {messages.map((item) => (
          <article key={item.id} className="p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-semibold text-green-950 dark:text-green-50">{item.subject}</h2>
              <span className={`text-xs ${item.read ? "text-green-700" : "text-orange-600"}`}>{item.read ? "Read" : "Unread"}</span>
            </div>
            <p className="mt-1 text-xs text-green-900/75 dark:text-green-100/75">
              {item.name} ({item.email}) - {new Date(item.createdAt).toLocaleString()}
            </p>
            <p className="mt-3 text-sm text-green-900/90 dark:text-green-100/90">{item.message}</p>
            <div className="mt-3 flex gap-2">
              <button onClick={() => onToggleRead(item.id)} className="border border-green-900/25 px-3 py-1 text-xs dark:border-green-50/25">
                Mark as {item.read ? "unread" : "read"}
              </button>
              <button onClick={() => onDelete(item.id)} className="border border-orange-500 px-3 py-1 text-xs text-orange-700 dark:border-orange-300 dark:text-orange-200">
                Delete
              </button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function AdminSettingsPage({
  settings,
  onSaveSettings,
  onChangePassword,
}: {
  settings: SiteSettings;
  onSaveSettings: (settings: SiteSettings) => void;
  onChangePassword: (currentPassword: string, newPassword: string) => boolean;
}) {
  const [siteForm, setSiteForm] = useState(settings);
  const [passwordForm, setPasswordForm] = useState({ current: "", next: "", confirm: "" });
  const [passwordFeedback, setPasswordFeedback] = useState("");

  useEffect(() => {
    setSiteForm(settings);
  }, [settings]);

  const saveSite = (event: FormEvent) => {
    event.preventDefault();
    onSaveSettings(siteForm);
  };

  const changePassword = (event: FormEvent) => {
    event.preventDefault();
    if (passwordForm.next !== passwordForm.confirm) {
      setPasswordFeedback("New password and confirm password do not match.");
      return;
    }
    const ok = onChangePassword(passwordForm.current, passwordForm.next);
    setPasswordFeedback(ok ? "Password updated successfully." : "Current password is incorrect.");
    if (ok) {
      setPasswordForm({ current: "", next: "", confirm: "" });
    }
  };

  return (
    <section className="space-y-8">
      <h1 className="text-3xl font-bold text-green-950 dark:text-green-50">Settings</h1>

      <form onSubmit={saveSite} className="space-y-4 border border-green-900/15 p-4 dark:border-green-50/15">
        <h2 className="text-xl font-semibold text-green-950 dark:text-green-50">Site Identity & Social Links</h2>
        <div className="grid gap-3 md:grid-cols-2">
          <input
            value={siteForm.siteTitle}
            onChange={(event) => setSiteForm((prev) => ({ ...prev, siteTitle: event.target.value }))}
            placeholder="Site title"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <input
            value={siteForm.logoText}
            onChange={(event) => setSiteForm((prev) => ({ ...prev, logoText: event.target.value }))}
            placeholder="Logo text"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <input
            value={siteForm.socialLinks.instagram}
            onChange={(event) =>
              setSiteForm((prev) => ({ ...prev, socialLinks: { ...prev.socialLinks, instagram: event.target.value } }))
            }
            placeholder="Instagram URL"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <input
            value={siteForm.socialLinks.youtube}
            onChange={(event) =>
              setSiteForm((prev) => ({ ...prev, socialLinks: { ...prev.socialLinks, youtube: event.target.value } }))
            }
            placeholder="YouTube URL"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <input
            value={siteForm.socialLinks.x}
            onChange={(event) => setSiteForm((prev) => ({ ...prev, socialLinks: { ...prev.socialLinks, x: event.target.value } }))}
            placeholder="X URL"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
        </div>
        <button className="bg-green-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-green-800">Save Settings</button>
      </form>

      <form onSubmit={changePassword} className="space-y-4 border border-green-900/15 p-4 dark:border-green-50/15">
        <h2 className="text-xl font-semibold text-green-950 dark:text-green-50">Change Admin Password</h2>
        <div className="grid gap-3 md:grid-cols-3">
          <input
            type="password"
            value={passwordForm.current}
            onChange={(event) => setPasswordForm((prev) => ({ ...prev, current: event.target.value }))}
            placeholder="Current password"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <input
            type="password"
            value={passwordForm.next}
            onChange={(event) => setPasswordForm((prev) => ({ ...prev, next: event.target.value }))}
            placeholder="New password"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
          <input
            type="password"
            value={passwordForm.confirm}
            onChange={(event) => setPasswordForm((prev) => ({ ...prev, confirm: event.target.value }))}
            placeholder="Confirm new password"
            className="h-10 border border-green-900/20 px-3 text-sm dark:border-green-50/20 dark:bg-[#10271d]"
          />
        </div>
        {passwordFeedback && <p className="text-sm text-orange-600 dark:text-orange-300">{passwordFeedback}</p>}
        <button className="bg-green-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-green-800">Update Password</button>
      </form>
    </section>
  );
}

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);

  return null;
}

function AppShell() {
  const location = useLocation();
  const isAdminArea = location.pathname.startsWith("/admin");

  const [search, setSearch] = useState("");
  const [darkMode, setDarkMode] = useStoredState<boolean>("vr_theme_dark", false);
  const [showBackToTop, setShowBackToTop] = useState(false);

  const [siteSettings, setSiteSettings] = useStoredState<SiteSettings>("vr_settings", defaultSettings);
  const [adminCredentials, setAdminCredentials] = useStoredState<AdminCredentials>("vr_admin_credentials", defaultAdminCredentials);
  const [articles, setArticles] = useStoredState<Article[]>("vr_articles", seedArticles);
  const [media, setMedia] = useStoredState<MediaItem[]>(
    "vr_media",
    seedArticles
      .flatMap((item) => item.images)
      .slice(0, 18)
      .map((url, index) => ({ id: `seed-media-${index + 1}`, name: `seed-${index + 1}.jpg`, url, createdAt: nowISO() }))
  );
  const [messages, setMessages] = useStoredState<ContactMessage[]>("vr_messages", []);
  const [siteVisits, setSiteVisits] = useStoredState<number>("vr_site_visits", 0);

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(() => sessionStorage.getItem("vr_admin_auth") === "1");

  const publishedArticles = useMemo(() => articles.filter((item) => item.status === "Published"), [articles]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  useEffect(() => {
    const onScroll = () => setShowBackToTop(window.scrollY > 560);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!isAdminArea) {
      setSiteVisits((prev) => prev + 1);
    }
  }, [isAdminArea, location.pathname, setSiteVisits]);

  const login = (email: string, password: string) => {
    const ok = email === adminCredentials.email && password === adminCredentials.password;
    if (ok) {
      sessionStorage.setItem("vr_admin_auth", "1");
      setIsAdminAuthenticated(true);
    }
    return ok;
  };

  const logout = () => {
    sessionStorage.removeItem("vr_admin_auth");
    setIsAdminAuthenticated(false);
  };

  const upsertArticle = (article: Article) => {
    setArticles((prev) => {
      const exists = prev.some((item) => item.id === article.id);
      if (!exists) {
        return [{ ...article, views: 0 }, ...prev];
      }
      return prev.map((item) => (item.id === article.id ? { ...article, views: item.views } : item));
    });
  };

  const deleteArticle = (id: string) => {
    setArticles((prev) => prev.filter((item) => item.id !== id));
  };

  const addMedia = (items: { name: string; url: string }[]) => {
    const additions = items.map((item, index) => ({
      id: `media-${Date.now()}-${index}`,
      name: item.name,
      url: item.url,
      createdAt: nowISO(),
    }));
    setMedia((prev) => [...additions, ...prev]);
    return additions;
  };

  const trackProductView = (id: string) => {
    setArticles((prev) => prev.map((item) => (item.id === id ? { ...item, views: item.views + 1 } : item)));
  };

  const changePassword = (currentPassword: string, newPassword: string) => {
    if (adminCredentials.password !== currentPassword || !newPassword.trim()) {
      return false;
    }
    setAdminCredentials((prev) => ({ ...prev, password: newPassword }));
    return true;
  };

  return (
    <div className="min-h-screen bg-[#fffdf8] text-green-950 transition-colors dark:bg-[#08140f] dark:text-green-50">
      {!isAdminArea && <Header darkMode={darkMode} onToggle={() => setDarkMode((prev) => !prev)} settings={siteSettings} />}
      {!isAdminArea && <Breadcrumbs />}
      <ScrollToTop />

      <Routes>
        <Route
          path="/"
          element={<HomePage siteTitle={siteSettings.siteTitle} search={search} setSearch={setSearch} publishedArticles={publishedArticles} />}
        />
        <Route
          path="/category/:slug"
          element={<CategoryPage siteTitle={siteSettings.siteTitle} search={search} setSearch={setSearch} publishedArticles={publishedArticles} />}
        />
        <Route
          path="/product/:id"
          element={<ProductPage siteTitle={siteSettings.siteTitle} publishedArticles={publishedArticles} onTrackView={trackProductView} />}
        />
        <Route path="/about" element={<AboutPage siteTitle={siteSettings.siteTitle} />} />
        <Route
          path="/contact"
          element={
            <ContactPage
              siteTitle={siteSettings.siteTitle}
              socialLinks={siteSettings.socialLinks}
              onSubmitMessage={(payload) =>
                setMessages((prev) => [{ id: `msg-${Date.now()}`, read: false, createdAt: nowISO(), ...payload }, ...prev])
              }
            />
          }
        />

        <Route
          path="/admin/login"
          element={
            <AdminLoginPage
              siteTitle={siteSettings.siteTitle}
              isAuthenticated={isAdminAuthenticated}
              credentials={adminCredentials}
              onLogin={login}
            />
          }
        />

        <Route
          path="/admin"
          element={
            <ProtectedAdminRoute isAuthenticated={isAdminAuthenticated}>
              <AdminLayout onLogout={logout} />
            </ProtectedAdminRoute>
          }
        >
          <Route index element={<AdminDashboardHome articles={articles} siteVisits={siteVisits} />} />
          <Route path="articles" element={<AdminArticlesPage articles={articles} onDelete={deleteArticle} />} />
          <Route path="articles/new" element={<AdminArticleEditorPage articles={articles} media={media} onSave={upsertArticle} onAddMedia={addMedia} />} />
          <Route
            path="articles/:id/edit"
            element={<AdminArticleEditorPage articles={articles} media={media} onSave={upsertArticle} onAddMedia={addMedia} />}
          />
          <Route path="media" element={<AdminMediaManagerPage media={media} onAdd={addMedia} onDelete={(id) => setMedia((prev) => prev.filter((item) => item.id !== id))} />} />
          <Route
            path="messages"
            element={
              <AdminMessagesPage
                messages={messages}
                onToggleRead={(id) => setMessages((prev) => prev.map((item) => (item.id === id ? { ...item, read: !item.read } : item)))}
                onDelete={(id) => setMessages((prev) => prev.filter((item) => item.id !== id))}
              />
            }
          />
          <Route
            path="settings"
            element={<AdminSettingsPage settings={siteSettings} onSaveSettings={setSiteSettings} onChangePassword={changePassword} />}
          />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      {!isAdminArea && (
        <footer className="border-t border-green-900/10 py-8 text-center text-sm text-green-900/80 dark:border-green-50/10 dark:text-green-100/80">
          <p>{siteSettings.siteTitle} 2026. Honest reviews for Home, Cuisine, and Garden essentials.</p>
        </footer>
      )}

      {!isAdminArea && (
        <AnimatePresence>
          {showBackToTop && (
            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="fixed bottom-6 right-6 z-50 bg-green-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-green-800"
            >
              Back to top
            </motion.button>
          )}
        </AnimatePresence>
      )}
    </div>
  );
}

export default function App() {
  const isGithubPages = window.location.hostname.includes("github.io");
  const repoSegment = window.location.pathname.split("/").filter(Boolean)[0] ?? "";
  const routerBase = isGithubPages && repoSegment ? `/${repoSegment}` : "/";

  return (
    <BrowserRouter basename={routerBase}>
      <AppShell />
    </BrowserRouter>
  );
}
